export const environment = {
  production: true,
  ApiUrl: 'http://suaapiestraaqui',
  serverLog: 'http://suaapiaqui'
};
